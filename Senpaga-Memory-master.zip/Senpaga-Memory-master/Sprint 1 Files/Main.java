package randomWordGame;


public class Main {

	@SuppressWarnings("static-access")
	public static void main(String[] args) {
		
		UserInterface ui = new UserInterface();
		
		ui.optionsMenu();
	}

}
